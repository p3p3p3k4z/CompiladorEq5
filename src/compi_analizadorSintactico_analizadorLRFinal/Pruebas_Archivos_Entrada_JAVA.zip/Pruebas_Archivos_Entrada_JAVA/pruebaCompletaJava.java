public class pruebaCompletaJava {
    public static void main(string[][] args) {
        // Declaraciones de varios tipos de variables
        int a, b, j;
        float calif, pot, suma = 0.0f, sueldo, nsueldo;
        int categ = 2;
        

        system.out.println("Teclea un numero:");
        b = a % 2;
        int h = 1;
        if (h == 1){
            system.out.println(" h es 1");
        }

        if (b == 0) {
            system.out.println(" es un numero par");
        } else {
            system.out.println(" es un numero impar");
        }

        switch (categ) {
            case 1:
                nsueldo = sueldo * 10;
                break;
            case 2:
                nsueldo = sueldo * 5;
                break;
            default:
                nsueldo = sueldo * 1;
        }

        for (int i = 0; i < 4; i++) {
            pot = 1;
            suma = suma + 6;
        }

        int i = 0;

        while (i < 4) {
        }
        
        do {
            system.out.println("Teclea la calificacion ");
        } while (calif < 10);
        suma += 1;
        i++;
        
    }

    // Agregada una declaración de método
    int suma() {
        int x, y;
        float z = 1.1;
        int a = 1;
        return a;
     }
}
