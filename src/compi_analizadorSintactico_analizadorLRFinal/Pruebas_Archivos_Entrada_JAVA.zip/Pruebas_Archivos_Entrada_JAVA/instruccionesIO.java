public class instruccionesIO {
    public static void main(string[] args) {
        system.out.println("Hola, mundo");
        int a = 0;
        system.out.println("Hola de nuevo esto es una prueba");
     }
}
