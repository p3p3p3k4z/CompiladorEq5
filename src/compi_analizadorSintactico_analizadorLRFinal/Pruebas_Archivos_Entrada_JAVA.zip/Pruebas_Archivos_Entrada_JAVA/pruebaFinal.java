import java.util.Scanner;

public class pruebaFinal {
        public static void main(String[] args) {
        // Declaraciones de varios tipos de variables
        int a, b;
        /* Comentario
           de bloque */
        float c;
        int an;
        int [] vec = new int [10];
        int [][] vec1 = new int [10][10];
        int [] ar;
        float[] vecFloat = {2.3f, 5.0f, 3.1f};
        Scanner lectura = new Scanner(System.in);


        System.out.println("Ingrese un número entero: ");
        int numeroEntero = scanner.nextInt();
        
        System.out.println("Ingrese una cadena: ");
        String cadena = scanner.nextLine();

        
        System.out.println("Ingrese un número flotante: "+ c +an);
        System.out.println("Ingrese un número flotante: "+ 2.01f); 
        double equisde = scanner.nextDouble();
        System.out.println(a + " el numero es ");


        //a = scanner.nextInt();
        }

        int suma(int i, int f, float p) {
                int x, y;
                float z = 1.1f;
                int a = 1;
                return a;
             }
}
