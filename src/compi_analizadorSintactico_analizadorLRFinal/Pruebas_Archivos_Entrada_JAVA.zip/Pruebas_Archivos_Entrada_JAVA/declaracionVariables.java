public class declaracionVariables {
    public static void main(string[] args) {
       int x, y;
       float z = 1.1;
       int a = 1, b= 2;
       char c;
       char d = 'a';
       string s = "hola";
       boolean cc = true;
       public static int counting = 0;
       a = a+1;
       a = a+b;
       int k = 1+3;
       int j = a+b;
       int l = a*8;
       int m = a/8;
    }

}

