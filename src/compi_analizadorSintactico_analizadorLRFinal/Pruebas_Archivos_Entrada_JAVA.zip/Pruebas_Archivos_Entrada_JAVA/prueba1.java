public class prueba1 {
    public static void saludar() {
        System.out.println("Hola, mundo");
       int a = 5;
    }

    
    public static void main(String[] args) {
       float b = 6.12345633f;
    }
}
