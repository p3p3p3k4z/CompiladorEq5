public class prueba {
    public static void main(string[] args) {
        system.out.println("Hola, Mundo");
        int var_a=5+2;
        //Prueba de comentario 1
        float _i$32 = 1.0987f;
        /*
          System.out.println(x<vnfmgx);
          Prueba de comentario multilinea
         */
    } @
}