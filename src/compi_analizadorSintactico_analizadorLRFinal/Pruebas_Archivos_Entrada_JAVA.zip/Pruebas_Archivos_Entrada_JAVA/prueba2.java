public class prueba2 {
    public static void saludar() {
        system.out.println("Hola, mundo");
       int x = 5;
       x = 7;
    }
    @
    public static void equisde() {
        system.out.println("Hola, mundo");
        char x =  'z';
    }

    public static void main(string[] args) {
       float v = 1.234562f;
    }
}
